package jetbrains.buildServer.configs.kotlin.v2018_1.buildFeatures

import jetbrains.buildServer.configs.kotlin.v2018_1.*

/**
 * Build feature for notification rule
 * 
 * @see notifications
 */
open class Notifications() : BuildFeature() {

    init {
        type = "notifications"
    }

    constructor(init: Notifications.() -> Unit): this() {
        init()
    }

    /**
     * Notificator type
     */
    var notifier by stringParameter()

    /**
     * Branch filter
     */
    var branchFilter by stringParameter()

    /**
     * Send notification when build started
     */
    var buildStarted by booleanParameter(trueValue = "true", falseValue = "")

    /**
     * Send notification if build fails to start
     */
    var buildFailedToStart by booleanParameter(trueValue = "true", falseValue = "")

    /**
     * Send notification if build failed
     */
    var buildFailed by booleanParameter("buildFinishedFailure", trueValue = "true", falseValue = "")

    /**
     * Send notification if build failed for the first time after success
     */
    var firstFailureAfterSuccess by booleanParameter(trueValue = "true", falseValue = "")

    /**
     * Keep notifying until build is complete (even without my changes)
     */
    var notifyUntilBuildIsComplete by booleanParameter("buildFinishedNewFailure", trueValue = "true", falseValue = "")

    /**
     * Only notify on new build problem or new failed test
     */
    var newBuildProblemOccured by booleanParameter(trueValue = "true", falseValue = "")

    /**
     * Send notification if build finished successfully
     */
    var buildFinishedSuccessfully by booleanParameter("buildFinishedSuccess", trueValue = "true", falseValue = "")

    /**
     * Send notification if build is successfull for the first time after failure
     */
    var firstSuccessAfterFailure by booleanParameter(trueValue = "true", falseValue = "")

    /**
     * Notify when the first build error occurs
     */
    var firstBuildErrorOccurs by booleanParameter("buildFailing", trueValue = "true", falseValue = "")

    /**
     * Build is probably hanging
     */
    var buildProbablyHanging by booleanParameter(trueValue = "true", falseValue = "")

    override fun validate(consumer: ErrorConsumer) {
        super.validate(consumer)
    }
}


/**
 * Add notification rule
 */
fun BuildFeatures.notifications(init: Notifications.() -> Unit): Notifications {
    val result = Notifications(init)
    feature(result)
    return result
}
