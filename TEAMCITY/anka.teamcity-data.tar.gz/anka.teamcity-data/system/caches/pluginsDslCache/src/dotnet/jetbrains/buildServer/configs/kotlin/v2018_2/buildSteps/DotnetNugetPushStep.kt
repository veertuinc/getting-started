package jetbrains.buildServer.configs.kotlin.v2018_2.buildSteps

import jetbrains.buildServer.configs.kotlin.v2018_2.*

/**
 * A [dotnet nuget push step](https://github.com/JetBrains/teamcity-dotnet-plugin) to run .NET CLI command
 * 
 * @see dotnetNugetPush
 */
open class DotnetNugetPushStep() : BuildStep() {

    init {
        type = "dotnet"
        param("command", "nuget-push")
    }

    constructor(init: DotnetNugetPushStep.() -> Unit): this() {
        init()
    }

    /**
     * Specify paths to nuget packages. Wildcards are supported.
     */
    var packages by stringParameter("paths")

    /**
     * Specify the server URL. To use a TeamCity NuGet feed, specify the URL from the NuGet feed project settings page.
     */
    var serverUrl by stringParameter("nuget.packageSource")

    /**
     * Specify the API key to access the NuGet packages feed.
     * For the built-in TeamCity NuGet server use %teamcity.nuget.feed.api.key%.
     */
    var apiKey by stringParameter("secure:nuget.apiKey")

    /**
     * Do not publish an existing nuget symbols package
     */
    var noSymbols by booleanParameter("nuget.noSymbols", trueValue = "true", falseValue = "")

    /**
     * Enter additional command line parameters for dotnet nuget push.
     */
    var args by stringParameter()

    /**
     * Specify logging verbosity
     * @see Verbosity
     */
    var logging by enumParameter<Verbosity>("verbosity")

    /**
     * Specifies which Docker image platform will be used to run this build step.
     */
    var dockerImagePlatform by enumParameter<ImagePlatform>("plugin.docker.imagePlatform", mapping = ImagePlatform.mapping)

    /**
     * If enabled, "docker pull [image][dockerImage]" will be run before docker run.
     */
    var dockerPull by booleanParameter("plugin.docker.pull.enabled", trueValue = "true", falseValue = "")

    /**
     * Specifies which Docker image to use for running this build step. I.e. the build step will be run inside specified docker image, using 'docker run' wrapper.
     */
    var dockerImage by stringParameter("plugin.docker.imageId")

    /**
     * Additional docker run command arguments
     */
    var dockerRunParameters by stringParameter("plugin.docker.run.parameters")

    /**
     * Logging verbosity
     */
    enum class Verbosity {
        Quiet,
        Minimal,
        Normal,
        Detailed,
        Diagnostic;

    }
    /**
     * Docker image platforms
     */
    enum class ImagePlatform {
        Any,
        Linux,
        Windows;

        companion object {
            val mapping = mapOf<ImagePlatform, String>(Any to "", Linux to "linux", Windows to "windows")
        }

    }
    override fun validate(consumer: ErrorConsumer) {
        super.validate(consumer)
        if (packages == null && !hasParam("paths")) {
            consumer.consumePropertyError("packages", "mandatory 'packages' property is not specified")
        }
        if (serverUrl == null && !hasParam("nuget.packageSource")) {
            consumer.consumePropertyError("serverUrl", "mandatory 'serverUrl' property is not specified")
        }
        if (apiKey == null && !hasParam("secure:nuget.apiKey")) {
            consumer.consumePropertyError("apiKey", "mandatory 'apiKey' property is not specified")
        }
    }
}


/**
 * Adds a [dotnet nuget push step](https://github.com/JetBrains/teamcity-dotnet-plugin) to run .NET CLI command
 * @see DotnetNugetPushStep
 */
fun BuildSteps.dotnetNugetPush(init: DotnetNugetPushStep.() -> Unit): DotnetNugetPushStep {
    val result = DotnetNugetPushStep(init)
    step(result)
    return result
}
